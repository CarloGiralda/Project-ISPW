package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.io.IOException;

public class AccountSettingsController {
    @FXML
    private Button goBackButton;


    @FXML
    private Button changeUsernameButton;

    @FXML
    private Button changeLevelButton;

    @FXML
    private Button confirm1;

    @FXML
    private Button confirm2;

    @FXML
    private TextField usernameField;

    @FXML
    private TextField cookinglevelField;

    @FXML
    private Label usernameLabel;

    @FXML
    private Label cookinglevelLabel;


    @FXML
    public void goBack() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        Stage window=(Stage) goBackButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }


    //Devo fare in modo che cliccando sul textfield non si può scrivere
    @FXML
    public void changeU(){
        usernameLabel.setOpacity(1);
        usernameField.setEditable(true);
        usernameField.setText("");
    }

    @FXML
    public void changeCL(){
        cookinglevelLabel.setOpacity(1);
        cookinglevelField.setEditable(true);
        cookinglevelField.setText("");

    }

    @FXML
    public void appear_confirm_U_button(){
        System.out.println("click");
        confirm1.setDisable(false);
    }

    @FXML
    public void appear_confirm_CL_button(){
        System.out.println("click");
        confirm2.setDisable(false);
    }

    @FXML
    public void setConfirm1(){
        //TODO con db
    }

    @FXML
    public void setConfirm2(){
        //TODO con db
    }
}
