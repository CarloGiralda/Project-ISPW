package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class TutorialController {

    @FXML
    private Button goBackButton;

    @FXML
    private Button nextImage;

    @FXML
    private Button backImage;

    @FXML
    private ImageView view;


    private final Image image1 = new Image("C:\\Users\\gabriele\\Desktop\\Local4-ProgettoISPW\\src\\main\\resources\\images\\foglie.jpg"); ;
    private final Image image2 = new Image("C:\\Users\\gabriele\\Desktop\\Local4-ProgettoISPW\\src\\main\\resources\\images\\Carbonara.jpg"); ;
    private final Image image3 = new Image("C:\\Users\\gabriele\\Desktop\\Local4-ProgettoISPW\\src\\main\\resources\\images\\BackgroundGreen.jpg");
    private final Image image4 = new Image("C:\\Users\\gabriele\\Desktop\\Local4-ProgettoISPW\\src\\main\\resources\\images\\Insalata.jpg");

    private final Image[] allImages = {image1,image2,image3,image4};


    @FXML
    public void goBack() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Settings.fxml"));
        Stage window=(Stage) goBackButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    private Integer i = 0;
    private Integer prevImageNumber = 0;

    @FXML
    public int changeNextImage() {
        if(i==3){return 0;}

        i = (i+1)%4;

        view.preserveRatioProperty();
        view.setImage(allImages[i]);
        if(i>0){
            prevImageNumber = i-1;
        }


        System.out.println("i: "+i+" prev: "+prevImageNumber);
        return 1;
    }

    @FXML
    public int changePreviousImage(){

        if(prevImageNumber == 0){return 0;}

        view.preserveRatioProperty();
        view.setImage(allImages[prevImageNumber-1]);
        i = (i-1)%4;
        if(i>0) {
            prevImageNumber = prevImageNumber - 1;

        }
        System.out.println("i: "+i+" prev: "+prevImageNumber);
        return 1;
    }

}
