package com.example.progettoispw;

import java.util.ArrayList;

public class SavedControllerA {
    ArrayList<String> recipes= new ArrayList<>();
    ArrayList<RecipeBean> rcp=new ArrayList<>();

    public ArrayList<String> saved(String username) throws Exception {
        SavedDAO saved=new SavedDAO();
        rcp=saved.saveddao(username);
        for(int i=0; i<rcp.size(); i++){
            recipes.add(i, rcp.get(i).getName());
        }
        return recipes;
    }
}
