package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class HistoryController {
    @FXML
    private Button gotohomeButton;

    public void gotoHome() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Home.fxml")));
        Stage window=(Stage) gotohomeButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    //TODO Creare la cronologia delle ricette, aggiungere tasto per pulire la cronologia

}
