package com.example.progettoispw;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.*;

public class AddRecipeDAO {
    private static String USER = "Progetto";
    private static String PASS = "";
    private static String DB_URL = "jdbc:mysql://localhost:3306/progettoispw-db";
    private static String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";

    private static int num;

    public static void insertRecipe(RecipeBean rb, String username){
        Statement stmt = null;
        Connection conn = null;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            if(rb.getCookingLevel().equals("Beginner")){
                num=1;
            }else if(rb.getCookingLevel().equals("Intermediate")){
                num=2;
            }else if(rb.getCookingLevel().equals("Advanced")){
                num=3;
            }

            for(int i=0; i<IndexTrace.get()+1; i++){
                SimpleQueries.insertRecipeFromIngredient(username, rb.getName(), rb.getIngredient().get(i).getName(), num, rb.getCT(), rb.getAP(), rb.getType(), rb.getDescription(), rb.getIngredient().get(i).getAmount(), conn);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sendImage(String name, File file, InputStream fin){
        Statement stmt = null;
        Connection conn = null;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            SimpleQueries.insertImages(name, file, fin, conn);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
