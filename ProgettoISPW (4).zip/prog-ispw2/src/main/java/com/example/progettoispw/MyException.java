package com.example.progettoispw;

public class MyException extends Exception{
    public MyException(String level){
        super("Il livello "+ level +" non è contemplato dall'applicazione");
    }
}
