package com.example.progettoispw;

import java.io.IOException;
import java.util.ArrayList;

public class AlimentarPreferencesControllerA {
    private AlimentarDAO dao;
    private LogBean login;

    public AlimentarPreferencesControllerA() throws IOException, ClassNotFoundException {
        dao=new AlimentarDAO();
        login=FileInter.ReadLog();
    }

    public void setPref(String pref, ArrayList<String> all){
        if(pref.equals("I have no particular preferences")){
            pref="None";
        }
        dao.insertAP(login.getUser(), pref, all);
    }
}
