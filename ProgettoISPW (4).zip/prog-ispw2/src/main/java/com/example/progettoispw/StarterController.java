package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class StarterController {
    private static int rem;
    private static LogBean login;

    public static void Start(Stage stage) throws IOException {
        try {
            login = FileInter.ReadLog();
            if (login != null) {
                rem = login.getCheck();
                if (rem != 0 ) {
                    Parent root = FXMLLoader.load(StarterController.class.getResource("Home.fxml"));
                    stage.setScene(new Scene(root, 850, 594));
                    return;
                }
            }
            Parent root = FXMLLoader.load(StarterController.class.getResource("login.fxml"));
            stage.setScene(new Scene(root, 850, 594));
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
