package com.example.progettoispw;

import java.sql.*;

public class SimpleQueries {
    public static ResultSet selectUserFromName(String username, Connection conn) throws SQLException {
        String sql = "SELECT * FROM Utenti where Username = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static int insertUser(String username, String password, String cl, String email, String spec, Connection conn) throws SQLException {
        String sql = "INSERT INTO Utenti(Username, Password, Specializzazione, CookingLevel, Email) values (?,?,?,?,?)";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        prep.setString(2, password);
        prep.setString(3, spec);
        prep.setString(4, cl);
        prep.setString(5, email);
        System.out.println(sql);
        return prep.executeUpdate();
    }

    public static ResultSet getSaved(String username, Connection conn) throws SQLException {
        String sql = "SELECT * FROM ricettesalvate where Nome = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static ResultSet getRecipeFromName(String name, Connection conn) throws SQLException{
        String sql= "SELECT * FROM ricetteinserite where Nome = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, name);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static int insertRecipeIntoSaved(String name, String username, Connection conn) throws SQLException{
        String sql= "INSERT INTO ricettesalvate(Nome, Ricetta) values(?,?)";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        prep.setString(2, name);
        System.out.println(sql);
        return prep.executeUpdate();
    }
}
