package com.example.progettoispw;

import java.io.*;

public class FileInter {
    private static File file;

    public FileInter(){
        file=new File("Login.dat");
    }

    public static void WriteLog(Login login) throws IOException {
        file=new File("Login.dat");
        FileOutputStream fileOut = new FileOutputStream(file);
        ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
        objectOut.writeObject(login);
        objectOut.close();
        fileOut.close();
        System.out.println("Scrittura completata!");
    }

    public static Login ReadLog() throws IOException, ClassNotFoundException {
        file=new File("Login.dat");
        FileInputStream fileIn = new FileInputStream(file);
        ObjectInputStream objectIn = new ObjectInputStream(fileIn);
        Login login = (Login) objectIn.readObject();
        objectIn.close();
        fileIn.close();
        System.out.println("Lettura completata!");
        return login;
    }
}
