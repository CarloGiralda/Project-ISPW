package com.example.progettoispw;

import java.sql.*;

public class RegisterDAO {
    private Conn con;
    private Connection conn;
    private static RegisterDAO instance=null;

    private RegisterDAO(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static RegisterDAO getInstance(){
        if (RegisterDAO.instance == null)
            RegisterDAO.instance = new RegisterDAO();
        return instance;
    }

    public void registerdao(LogBean log) throws Exception{
        try {
            ResultSet rs = SimpleQueries.selectUserFromName(log.getUser(), conn);
            if (!rs.first()) { // rs empty
                SimpleQueries.insertUser(log.getUser(), log.getPass(), log.getCL(), log.getEmail(), log.getSpec(), conn);
            }else{
                Exception e = new Exception("User already registered: " + log.getUser());
                throw e;
            }
            rs.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
