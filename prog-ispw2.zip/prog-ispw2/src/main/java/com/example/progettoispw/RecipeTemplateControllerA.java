package com.example.progettoispw;

public class RecipeTemplateControllerA {
    private RecipeBean rb;
    private RecipeTemplateDAO dao;
    private Recipe recipe;

    public RecipeTemplateControllerA(){
        dao=RecipeTemplateDAO.getInstance();
    }

    public RecipeBean getRecipe(){
        recipe=dao.getRecipe();
        rb=Convert.ConvertEntityToBean(recipe);
        return rb;
    }
}
