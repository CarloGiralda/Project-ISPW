package com.example.progettoispw;

import java.util.ArrayList;

public class SavedControllerA {
    private ArrayList<String> recipes= new ArrayList<>();
    private ArrayList<RecipeBean> rcp=new ArrayList<>();
    private SavedDAO saved;

    public ArrayList<String> saved(String username) throws Exception {
        saved=SavedDAO.getInstance();
        rcp=saved.saveddao(username);
        recipes.clear();
        for(int i=0; i<rcp.size(); i++){
            recipes.add(i, rcp.get(i).getName());
        }
        return recipes;
    }
}
