package com.example.progettoispw;

import java.sql.*;

public class CookingLevelDAO {
    private int num;
    private static CookingLevelDAO instance=null;
    private Conn con;
    private Connection conn;

    private CookingLevelDAO(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static CookingLevelDAO getInstance(){
        if (CookingLevelDAO.instance == null)
            CookingLevelDAO.instance = new CookingLevelDAO();
        return instance;
    }

    public void insertCL(String CL, String username){
        try {
            if(CL.toLowerCase().equals("beginner")){
                num=1;
            }else if(CL.toLowerCase().equals("intermediate")){
                num=2;
            }else if(CL.toLowerCase().equals("advanced")){
                num=3;
            }

            SimpleQueries.insertCookingLevel(num, username, conn);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
