package com.example.progettoispw;

import java.io.IOException;

public class LoginControllerA {
    private LoginDAO dao;

    public boolean checkUserAndPass(LogBean a) throws IOException {
        LogBean save=new LogBean();
        dao=LoginDAO.getInstance();
        save= dao.Login(a.getUser());
        if(a.getUser().equals(save.getUser()) && a.getPass().equals(save.getPass())){
            FileInter.WriteLog(save);
            System.out.println("Login eseguito");
            return true;
        }else{
            System.out.println("Login fallito");
            return false;
        }
    }

    public void select() throws IOException, ClassNotFoundException {
        LogBean login=FileInter.ReadLog();
        login.setCheck();
        FileInter.WriteLog(login);
    }
}
