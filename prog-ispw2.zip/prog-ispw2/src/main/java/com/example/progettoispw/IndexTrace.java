package com.example.progettoispw;

public class IndexTrace {
    private static int i=0;

    public static void add() {
        i += 1;
    }

    public static int get(){
        return i;
    }

    public static void reset() { i=0; }
}
