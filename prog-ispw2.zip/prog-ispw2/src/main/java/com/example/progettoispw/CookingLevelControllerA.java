package com.example.progettoispw;

import java.io.IOException;

public class CookingLevelControllerA {
    private LogBean login;
    private CookingLevelDAO dao;

    public void setCL(String CL) throws IOException, ClassNotFoundException {
        login=FileInter.ReadLog();
        String username=login.getUser();
        dao=CookingLevelDAO.getInstance();
        dao.insertCL(CL, username);
        login.setCL(CL);
        FileInter.WriteLog(login);
    }
}
