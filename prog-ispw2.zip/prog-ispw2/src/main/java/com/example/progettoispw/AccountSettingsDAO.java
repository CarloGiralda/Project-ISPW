package com.example.progettoispw;

import java.sql.*;
import java.util.Locale;

public class AccountSettingsDAO {
    private MyException e;
    private Conn con;
    private Connection conn;
    private static AccountSettingsDAO instance=null;

    private AccountSettingsDAO(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public synchronized static AccountSettingsDAO getInstance(){
        if (AccountSettingsDAO.instance == null)
            AccountSettingsDAO.instance = new AccountSettingsDAO();
        return instance;
    }

    public void changeUser(String nameSet, String oldName) {
        try {
            SimpleQueries.setUserFromName(nameSet, oldName, conn);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int changePass(String username, String pass) {
        try {
            if(pass.equals("")){
                System.out.println("Password non valida");
                e=new MyException(pass);
                throw e;
            }

            SimpleQueries.setPassFromName(pass, username, conn);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (MyException e){
            e.printStackTrace();
            return 1; //password non valida
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0; //password cambiata
    }
}
