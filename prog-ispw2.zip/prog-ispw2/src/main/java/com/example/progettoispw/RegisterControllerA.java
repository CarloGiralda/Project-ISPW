package com.example.progettoispw;

import java.io.IOException;

public class RegisterControllerA {
    private LogBean login;
    private RegisterDAO dao;

    public void register(LogBean log) throws Exception{
        dao=RegisterDAO.getInstance();
        dao.registerdao(log);
    }

    public void initFile(LogBean log) throws IOException {
        login=new LogBean();
        login.setUser(log.getUser());
        login.setPass(log.getPass());
        login.setSpec(log.getCL());
        login.setCL(log.getCL());
        login.setEmail(log.getEmail());
        FileInter.WriteLog(login);
    }
}
