package com.example.progettoispw;

public class PaymentControllerA {

    private PaymentDao paydao;

    public void setPremiumUser(){
        paydao = PaymentDao.getInstance();
        paydao.insertPremiumUser();
    }
}
