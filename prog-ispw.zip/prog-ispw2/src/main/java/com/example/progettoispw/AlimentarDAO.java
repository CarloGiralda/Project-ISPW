package com.example.progettoispw;

import java.sql.*;
import java.util.ArrayList;

public class AlimentarDAO {
    private String AP;
    private ArrayList<String> all;
    private Conn con;
    private Connection conn;
    private static AlimentarDAO instance=null;

    private AlimentarDAO(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static AlimentarDAO getInstance(){
        if (AlimentarDAO.instance == null)
            AlimentarDAO.instance = new AlimentarDAO();
        return instance;
    }

    public void insertAP(String username, String pref, ArrayList<String> all){
        ResultSet rs;

        try {
            SimpleQueries.insertAlimentarPreferences(username, pref, conn);
            if(all.isEmpty()){
                return;
            }else if(!all.get(0).equals("No allergies")) {
                rs=SimpleQueries.getAllergies(username, conn);
                rs.first();
                for (int i = 0; i < all.size(); i++) {
                    SimpleQueries.insertAllergies(username, all.get(i), conn);
                }
            }else{
                rs=SimpleQueries.getAllergies(username, conn);
                rs.first();
                if(!rs.getString("Allergy").equals("")){
                    SimpleQueries.deleteAllergies(username, conn);
                }
                rs.close();
            }

        } catch (SQLIntegrityConstraintViolationException e){
            all.remove(0);
            instance.insertAP(username, pref, all);
            System.out.println("Alimentar Preference already inserted");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getPref(String username){
        try {
            ResultSet rs=SimpleQueries.getPref(username, conn);
            rs.first();
            AP=rs.getString("AlimentarPreferences");

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return AP;
    }

    public ArrayList<String> getAll(String username) {
        all=new ArrayList<>();

        try {
            ResultSet rs=SimpleQueries.getAllergies(username, conn);
            if(!rs.first()){
                all.add("No Allergies");
            }else {
                rs.first();
                do {
                    // lettura delle colonne "by ap"
                    all.add(rs.getString("Allergy"));
                } while (rs.next());
                rs.close();
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return all;
    }

    public void clear(String username){
        try {
            SimpleQueries.deleteAllergies(username, conn);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
