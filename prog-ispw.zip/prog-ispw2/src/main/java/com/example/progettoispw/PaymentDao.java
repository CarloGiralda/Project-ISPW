package com.example.progettoispw;

import java.sql.Connection;

public class PaymentDao {

    private static PaymentDao instance=null;
    private Conn con;
    private Connection conn;

    private PaymentDao(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static PaymentDao getInstance(){
        if (PaymentDao.instance == null)
            PaymentDao.instance = new PaymentDao();
        return instance;
    }

    //TODO insert on DB
    public void insertPremiumUser(){}

}
