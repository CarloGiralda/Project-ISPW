package com.example.progettoispw;

import java.io.IOException;
import java.util.ArrayList;

public class AlimentarPreferencesControllerA {
    private AlimentarDAO dao;
    private LogBean login;
    private ArrayList<String> pref;

    public AlimentarPreferencesControllerA() throws IOException, ClassNotFoundException {
        dao=AlimentarDAO.getInstance();
        login=FileInter.ReadLog();
    }

    public void setPref(String pref, ArrayList<String> all) throws IOException {
        if(pref.equals("I have no particular preferences")){
            pref="None";
        }
        dao.insertAP(login.getUser(), pref, all);
        login.setAP(pref);
        FileInter.WriteLog(login);
    }

    public String getPref(){
        String pref=dao.getPref(login.getUser());
        return pref;
    }

    public ArrayList<String> getAll(){
        ArrayList<String> all=dao.getAll(login.getUser());
        return all;
    }

    public void clear(){
        dao.clear(login.getUser());
    }
}
