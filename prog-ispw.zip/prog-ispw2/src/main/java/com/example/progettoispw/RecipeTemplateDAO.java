package com.example.progettoispw;

import java.sql.*;

public class RecipeTemplateDAO {
    private static RecipeTemplateDAO instance=null;
    private Conn con;
    private Connection conn;

    private RecipeTemplateDAO(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static RecipeTemplateDAO getInstance(){
        if (RecipeTemplateDAO.instance == null)
            RecipeTemplateDAO.instance = new RecipeTemplateDAO();
        return instance;
    }

    public Recipe getRecipe() {

        return null;
    }
}
