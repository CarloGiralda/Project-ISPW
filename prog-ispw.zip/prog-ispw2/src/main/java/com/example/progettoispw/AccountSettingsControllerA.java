package com.example.progettoispw;

import java.io.IOException;

public class AccountSettingsControllerA {
    private LogBean login;
    private AccountSettingsDAO dao;

    public AccountSettingsControllerA(){
        dao=AccountSettingsDAO.getInstance();
    }

    public void confirmUser(String username) throws IOException, ClassNotFoundException {
        login=FileInter.ReadLog();
        //si prende l'username dal file Login.dat e lo si sostituisce nel db con il nuovo nome
        dao.changeUser(username, login.getUser());
        //si cambia anche il file Login.dat
        login.setUser(username);
        FileInter.WriteLog(login);
    }

    public int confirmPass(String pass) throws IOException, ClassNotFoundException {
        login=FileInter.ReadLog();
        //si prende l'username dal file Login.dat e si sostituisce nel db la password con la nuova immessa
        if(dao.changePass(login.getUser(), pass)==1){
            return 1;
        }
        //si cambia anche il file Login.dat
        login.setPass(pass);
        FileInter.WriteLog(login);
        return 0;
    }

    public void deselect() throws IOException, ClassNotFoundException {
        login=FileInter.ReadLog();
        login.desetCheck();
        FileInter.WriteLog(login);
    }
}
