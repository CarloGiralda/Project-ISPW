package com.example.progettoispw;

import java.sql.*;
import java.util.ArrayList;

public class AlimentarDAO {
    private static String USER = "Progetto";
    private static String PASS = "";
    private static String DB_URL = "jdbc:mysql://localhost:3306/progettoispw-db";
    private static String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";

    private static String AP;
    private static ArrayList<String> all;

    public static void insertAP(String username, String pref, ArrayList<String> all){
        Statement stmt = null;
        Connection conn = null;
        ResultSet rs;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            SimpleQueries.insertAlimentarPreferences(username, pref, conn);
            if(all.isEmpty()){
                return;
            }else if(!all.get(0).equals("No allergies")) {
                rs=SimpleQueries.getAllergies(username, conn);
                rs.first();
                for (int i = 0; i < all.size(); i++) {
                    SimpleQueries.insertAllergies(username, all.get(i), conn);
                }
            }else{
                rs=SimpleQueries.getAllergies(username, conn);
                rs.first();
                if(!rs.getString("Allergy").equals("")){
                    SimpleQueries.deleteAllergies(username, conn);
                }
                rs.close();
            }

        } catch (SQLIntegrityConstraintViolationException e){
            all.remove(0);
            AlimentarDAO.insertAP(username, pref, all);
            System.out.println("Alimentar Preference already inserted");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String getPref(String username){
        Statement stmt = null;
        Connection conn = null;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            ResultSet rs=SimpleQueries.getPref(username, conn);
            rs.first();
            AP=rs.getString("AlimentarPreferences");

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return AP;
    }

    public ArrayList<String> getAll(String username) {
        Statement stmt = null;
        Connection conn = null;
        all=new ArrayList<>();

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            ResultSet rs=SimpleQueries.getAllergies(username, conn);
            if(!rs.first()){
                all.add("No Allergies");
            }else {
                rs.first();
                do {
                    // lettura delle colonne "by ap"
                    all.add(rs.getString("Allergy"));
                } while (rs.next());
                rs.close();
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return all;
    }

    public void clear(String username){
        Statement stmt = null;
        Connection conn = null;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            SimpleQueries.deleteAllergies(username, conn);

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
