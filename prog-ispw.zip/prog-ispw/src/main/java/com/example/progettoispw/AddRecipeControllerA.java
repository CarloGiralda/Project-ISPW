package com.example.progettoispw;

import com.example.progettoispw.RecipeModel.Ingredient;
import javafx.stage.FileChooser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class AddRecipeControllerA {
    private AddRecipeDAO dao;
    private LogBean login;
    private File file;
    private File act;
    private Recipe recipe;

    public AddRecipeControllerA() throws IOException, ClassNotFoundException {
        dao=new AddRecipeDAO();
        login=FileInter.ReadLog();
    }

    public void addRecipe(RecipeBean rb){
        recipe=Convert.ConvertBeanToEntity(rb);
        dao.insertRecipe(recipe, login.getUser());
    }

    public File saveIm(){
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images file","*.jpg","*.png"));

        file = fc.showOpenDialog(null);
        fc.setInitialDirectory(file.getParentFile());
        return file;
    }

    public void sendIm(String name) throws FileNotFoundException {
        act=new File(String.valueOf(file));
        InputStream fin = new java.io.FileInputStream(act);
        dao.sendImage(name, login.getUser(), act, fin);
    }

    public Ingredient createBean(String name, String amount){
        Ingredient ingredient=new Ingredient(name, amount);
        return ingredient;
    }
}
