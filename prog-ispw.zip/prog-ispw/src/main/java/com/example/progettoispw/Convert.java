package com.example.progettoispw;

public class Convert {
    private static Recipe recipe;
    private static RecipeBean recb;

    public static Recipe ConvertBeanToEntity(RecipeBean rb){
        recipe=new Recipe(rb.getName());
        if(rb.getAP()!=null) {
            recipe.setAP(rb.getAP());
        }
        if(rb.getCookingLevel()!=null){
            recipe.setCookingLevel(rb.getCookingLevel());
        }
        if(rb.getImage()!=null){
            recipe.setImage(rb.getImage());
        }
        if(rb.getIngredient()!=null){
            recipe.addIngredient(rb.getIngredient());
        }
        if(rb.getChef()!=null){
            recipe.setChef(rb.getChef());
        }
        if(rb.getCT()!=null){
            recipe.setCT(rb.getCT());
        }
        if(rb.getDescription()!=null){
            recipe.setDescription(rb.getDescription());
        }
        if(rb.getType()!=null){
            recipe.setType(rb.getType());
        }
        if(rb.getAll()!=null){
            recipe.addAll(rb.getAll());
        }
        return recipe;
    }

    public static RecipeBean ConvertEntityToBean(Recipe rec){
        recb=new RecipeBean(rec.getName());
        if(rec.getAP()!=null) {
            recb.setAP(rec.getAP());
        }
        if(rec.getCookingLevel()!=null){
            recb.setCookingLevel(rec.getCookingLevel());
        }
        if(rec.getImage()!=null){
            recb.setImage(rec.getImage());
        }
        if(rec.getIngredient()!=null){
            recb.addIngredient(rec.getIngredient());
        }
        if(rec.getChef()!=null){
            recb.setChef(rec.getChef());
        }
        if(rec.getCT()!=null){
            recb.setCT(rec.getCT());
        }
        if(rec.getDescription()!=null){
            recb.setDescription(rec.getDescription());
        }
        if(rec.getType()!=null){
            recb.setType(rec.getType());
        }
        if(rec.getAll()!=null){
            recb.addAll(rec.getAll());
        }
        return recb;
    }
}
