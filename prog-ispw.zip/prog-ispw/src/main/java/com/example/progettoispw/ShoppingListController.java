package com.example.progettoispw;

import com.example.progettoispw.RecipeModel.Ingredient;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class ShoppingListController implements Initializable {
    @FXML
    private Button gotohomeButton;

    @FXML
    private TextField nameField;

    @FXML
    private TextField amountField;

    @FXML
    private TableView<Ingredient> listTable;

    @FXML
    private  TableColumn<Ingredient,String> nameCol;

    @FXML
    private  TableColumn<Ingredient,String> amountCol;

    ObservableList<Ingredient> observableList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        amountCol.setCellValueFactory(new PropertyValueFactory<>("amount"));
        listTable.setItems(observableList);
    }

    @FXML
    public void gotoHome() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Home.fxml")));
        Stage window=(Stage) gotohomeButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void addIngredient(){
        String ingName = nameField.getText();
        String ingAm = amountField.getText();
        if(!ingName.isEmpty() && !ingAm.isEmpty()){
            listTable.getItems().add(new Ingredient(ingName,ingAm));
            nameField.setText("");
            amountField.setText("");
        }
    }

    @FXML
    public void removeIngredient(){
        ObservableList<Ingredient> singleIngredient;
        observableList = listTable.getItems();
        singleIngredient = listTable.getSelectionModel().getSelectedItems();
        singleIngredient.forEach(observableList::remove);

    }

    //TODO download e search

}
