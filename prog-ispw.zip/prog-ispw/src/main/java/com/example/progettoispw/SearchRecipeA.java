package com.example.progettoispw;

import java.util.ArrayList;

public class SearchRecipeA {
    private String recipe;
    private SearchDAO dao;
    private ArrayList<Recipe> recipes;
    private ArrayList<RecipeBean> rbs;

    public SearchRecipeA(){
        dao=new SearchDAO();
        rbs=new ArrayList<>();
    }

    public ArrayList<RecipeBean> searchRecipe(RecipeBean rb) throws Exception {
        recipe=rb.getName();
        recipes=dao.searchRec(recipe);
        for(int i=0; i<recipes.size(); i++) {
            rbs.add(new RecipeBean(recipes.get(i).getName(), recipes.get(i).getChef(), recipes.get(i).getImage()));
        }
        return rbs;
    }
}
