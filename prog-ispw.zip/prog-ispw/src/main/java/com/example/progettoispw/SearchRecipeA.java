package com.example.progettoispw;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class SearchRecipeA {
    private String recipe;
    private SearchDAO dao;
    private ArrayList<Recipe> recipes;
    private ArrayList<RecipeBean> rbs;
    private LogBean login;

    public SearchRecipeA() throws IOException, ClassNotFoundException {
        dao=new SearchDAO();
        login=FileInter.ReadLog();
    }

    public ArrayList<RecipeBean> searchRecipe(RecipeBean rb) throws Exception {
        rbs=new ArrayList<>();
        recipe=rb.getName();
        recipes=dao.searchRec(recipe, login.getCL(), login.getAP());

        // controllo delle allergie
loop:   for(int i=0; i<recipes.size(); i++) {
            for(int j=0; j<login.getAll().size(); j++){
                for(int k=0; k<recipes.get(i).getAll().size(); k++){
                    if(login.getAll().get(j).equals(recipes.get(i).getAll().get(k))){
                        continue loop;
                    }
                }
            }
            rbs.add(new RecipeBean(recipes.get(i).getName(), recipes.get(i).getChef(), recipes.get(i).getImage()));
        }
        return rbs;
    }

    public ArrayList<RecipeBean> searchRecipeTime(String time) throws Exception {
        rbs=new ArrayList<>();
        recipes=dao.searchRecipe(time, login.getCL(), login.getAP());

        // controllo delle allergie
loop:   for(int i=0; i<recipes.size(); i++) {
            for(int j=0; j<login.getAll().size(); j++){
                for(int k=0; k<recipes.get(i).getAll().size(); k++){
                    if(login.getAll().get(j).equals(recipes.get(i).getAll().get(k))){
                        continue loop;
                    }
                }
            }
            rbs.add(Convert.ConvertEntityToBean(recipes.get(i)));
        }
        return rbs;
    }
}
