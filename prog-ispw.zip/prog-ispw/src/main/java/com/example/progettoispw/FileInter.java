package com.example.progettoispw;

import java.io.*;

public class FileInter {
    private static File file;

    public static void WriteLog(LogBean login) throws IOException {
        file=new File("Utente.dat");
        FileOutputStream fileOut = new FileOutputStream(file);
        ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
        objectOut.writeObject(login);
        objectOut.close();
        fileOut.close();
        System.out.println("Scrittura completata!");
    }

    public static LogBean ReadLog() throws IOException, ClassNotFoundException {
        try {
            file = new File("Utente.dat");
            FileInputStream fileIn = new FileInputStream(file);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            LogBean login = (LogBean) objectIn.readObject();
            objectIn.close();
            fileIn.close();
            System.out.println("Lettura completata!");
            return login;
        }catch(FileNotFoundException e) {
            return null;
        }
    }
}
