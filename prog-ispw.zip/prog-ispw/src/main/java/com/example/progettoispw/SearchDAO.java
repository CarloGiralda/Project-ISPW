package com.example.progettoispw;

import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class SearchDAO {
    private String USER = "Progetto";
    private String PASS = "";
    private String DB_URL = "jdbc:mysql://localhost:3306/progettoispw-db";
    private String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";

    private ArrayList<Recipe> recipes;
    private String ric;
    private String nome;
    private byte[] image;
    private Blob blob;
    private int num;
    private String allergies;
    private ArrayList<String> names;

    public ArrayList<Recipe> searchRec(String name, String CL, String AP) throws Exception{
        Statement stmt = null;
        Connection conn = null;
        recipes=new ArrayList<>();

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            if(CL.toLowerCase().equals("beginner")){
                num=1;
            }else if(CL.toLowerCase().equals("intermediate")){
                num=2;
            }else if(CL.toLowerCase().equals("advanced")){
                num=3;
            }

            ResultSet rs=SimpleQueries.getRecipeFromNameCLAPAll(name, num, AP, conn);
            ResultSet pq=SimpleQueries.getImage(name, conn);
            if(!rs.first() || !pq.first()){
                MyException e = new MyException("Ricetta o immagine non trovata");
                throw e;
            }
            rs.first();
            num=0;
            do {
                // lettura delle colonne "by ricetta"
                ric=rs.getString("Ricetta");
                nome=rs.getString("Nome");
                allergies=rs.getString("Allergies");
                blob=pq.getBlob("IMG");

                image=blob.getBytes(1, (int) blob.length());
                recipes.add(new Recipe(ric, nome, image));
                StringTokenizer st = new StringTokenizer(allergies);
                while (st.hasMoreTokens()) {
                    recipes.get(num).addAll(st.nextToken());
                }
                num++;
            } while (rs.next() && pq.next());
            rs.close();
            pq.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return recipes;
    }

    public ArrayList<Recipe> searchRecipe(String time, String CL, String AP) throws Exception{
        Statement stmt = null;
        Connection conn = null;
        recipes=new ArrayList<>();
        names=new ArrayList<>();
        ResultSet pq;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            if(CL.toLowerCase().equals("beginner")){
                num=1;
            }else if(CL.toLowerCase().equals("intermediate")){
                num=2;
            }else if(CL.toLowerCase().equals("advanced")){
                num=3;
            }

            ResultSet rs=SimpleQueries.getRecipeFromTimeCLAPAll(time, num, AP, conn);
            if(!rs.first()){
                MyException e = new MyException("Ricetta non trovata");
                throw e;
            }
            rs.first();
            num=0;
            do {
                // lettura delle colonne "by ricetta"
                ric=rs.getString("Ricetta");
                nome=rs.getString("Nome");
                allergies=rs.getString("Allergies");

                if(num==0 || !names.get(num-1).equals(nome)) {
                    pq = SimpleQueries.getImageFromChef(ric, nome, conn);
                    if (!pq.first()) {
                        MyException e = new MyException("Immagine non trovata");
                        throw e;
                    }
                    blob = pq.getBlob("IMG");

                    image = blob.getBytes(1, (int) blob.length());
                    recipes.add(new Recipe(ric, nome, image));
                    StringTokenizer st = new StringTokenizer(allergies);
                    while (st.hasMoreTokens()) {
                        recipes.get(num).addAll(st.nextToken());
                    }
                    num++;

                    pq.close();
                    names.add(nome);
                }
            } while (rs.next());
            rs.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return recipes;
    }
}
