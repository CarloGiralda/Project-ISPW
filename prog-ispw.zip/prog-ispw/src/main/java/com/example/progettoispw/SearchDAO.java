package com.example.progettoispw;

import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;

public class SearchDAO {
    private String USER = "Progetto";
    private String PASS = "";
    private String DB_URL = "jdbc:mysql://localhost:3306/progettoispw-db";
    private String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";

    private ArrayList<Recipe> recipes;
    private String ric;
    private String nome;
    private byte[] image;
    private Blob blob;

    public ArrayList<Recipe> searchRec(String name) throws Exception{
        Statement stmt = null;
        Connection conn = null;
        recipes=new ArrayList<>();

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            ResultSet rs=SimpleQueries.getRecipeFromName(name, conn);
            ResultSet pq=SimpleQueries.getImage(name, conn);
            if(!rs.first() || !pq.first()){
                MyException e = new MyException("Ricetta o immagine non trovata");
                throw e;
            }
            rs.first();
            do {
                // lettura delle colonne "by ricetta"
                ric=rs.getString("Ricetta");
                nome=rs.getString("Nome");
                blob=pq.getBlob("IMG");

                image=blob.getBytes(1, (int) blob.length());
                recipes.add(new Recipe(ric, nome, image));
            } while (rs.next() && pq.next());
            rs.close();
            pq.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return recipes;
    }
}
