package com.example.progettoispw;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.Objects;

public class AddRecipeController {
    @FXML private TextArea insertTitle;
    @FXML private TextArea addDescription;
    @FXML private TextArea preparationTime;
    @FXML private TextArea cookingTime;

    @FXML Label dtype;
    @FXML private MenuItem m1;
    @FXML private MenuItem m2;
    @FXML private MenuItem m3;
    @FXML private MenuItem m4;
    @FXML private MenuItem m5;
    @FXML private MenuItem m6;

    @FXML private Button addIngredient;

    @FXML private TextField ingredientName;
    @FXML private TextField ingredientAmount;

    @FXML Label selectedButton;


    @FXML private Button uploadImage;

    @FXML private Button goBackButton;
    @FXML private Button confirmRecipeButton;


    @FXML
    public void handleDishType(ActionEvent actionEvent){
        dtype.setText(((MenuItem)actionEvent.getSource()).getText());
        System.out.println(dtype.getText() + " selected");

    }

    @FXML
    public void handleDifficult(ActionEvent actionEvent){
        selectedButton.setText(((RadioButton)actionEvent.getSource()).getText());
        System.out.println(selectedButton.getText() + " selected");

    }

    @FXML
    public void goBack() throws IOException {
        //TODO Forse è possibile usare pattern GOF state per tornare nella home, nello stato recipe.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("home.fxml")));
        Stage window = (Stage) goBackButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void handleUploadImage(){
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images file","*.jpg","*.png"));

        try{
            File file = fc.showOpenDialog(null);
            fc.setInitialDirectory(file.getParentFile());
        }
        catch (Exception ex){
            //TODO
        }
    }


    @FXML
    public void commitRecipe() throws IOException{
        String title = insertTitle.getText();
        String description = addDescription.getText();

        String pT = preparationTime.getText();
        String cT = cookingTime.getText();
        int preparationTime = convertIntParameter(pT);
        int cookingTime = convertIntParameter(cT);
        String iName = ingredientName.getText();
        String iAmount = ingredientAmount.getText();
        String type = selectedButton.getText();

        if(!title.isEmpty() && !description.isEmpty() && !pT.isEmpty() && !cT.isEmpty() && !iName.isEmpty() && !iAmount.isEmpty()){
            //TODO send recipe
            confirmRecipeButton.setOpacity(1);
            confirmRecipeButton.setDisable(false);
        }

        System.out.println(title+'\n'+type+'\n'+description+'\n'+preparationTime+'\n'+cookingTime+'\n'+iName+'\n'+iAmount);

        //RecipeBean rb = new RecipeBean();
        //AddRecipeApplicativeController c = new AddRecipeApplicativeController();
        //c.compileRecipe(rb);

    }

    @FXML
    public void handleAddIngredient(){
        System.out.println("Clicked");
        //TODO
    }


    //TODO nel controller applicativo
    public int convertIntParameter(String str){
        int value = 0;
        try{
            value = Integer.parseInt(str);
        }
        catch (NumberFormatException ex){
            ex.printStackTrace();
        }
        return value;
    }


}