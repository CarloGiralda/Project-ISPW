package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.SubScene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class SettingsController {

    @FXML
    private Button homeButton;

    @FXML
    private Button cookingLevelButton;

    @FXML
    private Button privacyButton;

    private SavedControllerA sca;
    private ArrayList<String> recipes=new ArrayList<>();
    private ArrayList<Button> buttons=new ArrayList<>();

    public SettingsController(){
        sca=new SavedControllerA();
    }

    @FXML
    public void gotoCookingLevel() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("CookingLevel.fxml"));
        Stage window=(Stage) cookingLevelButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }
    @FXML
    public void gotoPrivacy() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("PrivacySettings.fxml"));
        Stage window=(Stage) privacyButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }
    @FXML
    public void gotoAccount(){
        //TODO
    }

    @FXML
    public void gotoTutorial(){
        //TODO
    }


    @FXML
    public void gotoHome() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
        Stage window=(Stage) homeButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }


}
