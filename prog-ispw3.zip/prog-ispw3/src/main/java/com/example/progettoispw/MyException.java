package com.example.progettoispw;

public class MyException extends Exception{
    public MyException(String level){
        super(level);
    }
}
