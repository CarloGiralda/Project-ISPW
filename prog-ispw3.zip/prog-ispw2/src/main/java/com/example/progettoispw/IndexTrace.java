package com.example.progettoispw;

public class IndexTrace {
    private static int i=0;
    private static int j=0;

    public static void add() {
        i += 1;
    }

    public static int get(){
        return i;
    }

    public static void reset() { i=0; }

    public static void set(int index){ i=index; }

    public static void tempadd() { j += 1; }

    public static int tempget(){
        return j;
    }

    public static void tempreset() { j=0; }

    public static void tempset(int index){ j=index; }
}
