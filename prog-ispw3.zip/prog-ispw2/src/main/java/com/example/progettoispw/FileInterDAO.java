package com.example.progettoispw;

import java.io.*;

public class FileInterDAO {
    private static File file;
    private static FileInterDAO instance=null;

    private FileInterDAO(){}

    public static FileInterDAO getInstance(){
        if(FileInterDAO.instance==null)
            FileInterDAO.instance=new FileInterDAO();
        return instance;
    }

    public void WriteLog(Login login) throws IOException {
        file=new File("Utente.dat");
        FileOutputStream fileOut = new FileOutputStream(file);
        ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
        objectOut.writeObject(login);
        objectOut.close();
        fileOut.close();
        System.out.println("Scrittura completata!");
    }

    public Login ReadLog() throws IOException, ClassNotFoundException {
        try {
            file = new File("Utente.dat");
            FileInputStream fileIn = new FileInputStream(file);
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            Login login = (Login) objectIn.readObject();
            objectIn.close();
            fileIn.close();
            System.out.println("Lettura completata!");
            return login;
        }catch(FileNotFoundException e) {
            return null;
        }
    }
}
