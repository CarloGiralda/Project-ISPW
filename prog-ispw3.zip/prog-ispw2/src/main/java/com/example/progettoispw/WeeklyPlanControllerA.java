package com.example.progettoispw;

import java.io.IOException;

public class WeeklyPlanControllerA {
    private Login login;
    private WeeklyPlanDAO dao;
    private FileInterDAO filedao;

    public WeeklyPlanControllerA() throws IOException, ClassNotFoundException {
        filedao=FileInterDAO.getInstance();
        login=filedao.ReadLog();
        dao=WeeklyPlanDAO.getInstance();
    }

    public boolean getPremiumUser(){
        if(login.getPremium()){
            return true;
        }else{
            if(dao.getFromDB(login.getUser())) {
                login.setPremium();
            }
            return login.getPremium();
        }
    }
}
