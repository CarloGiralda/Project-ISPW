package com.example.progettoispw;

import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class SearchDAO extends SubjectSearchDAO{
    private ArrayList<Recipe> recipes;
    private ArrayList<Recipe> states;
    private String ric;
    private String nome;
    private byte[] image;
    private Blob blob;
    private String allergies;
    private ArrayList<String> names;
    private int state=0;
    private int internalstate=0;
    private Conn con;
    private Connection conn;
    private static SearchDAO instance=null;

    private SearchDAO(){
        recipes=new ArrayList<>();
        names=new ArrayList<>();
        states=new ArrayList<>();
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static SearchDAO getInstance(){
        if (SearchDAO.instance == null)
            SearchDAO.instance = new SearchDAO();
        return instance;
    }

    public ArrayList<Recipe> searchRec(String name, String CL, String AP, String username) throws Exception{
        int num;

        try {
            num=instance.checkCL(CL,username);
            if(AP==null){
                AP=instance.getAP(username);
            }
            recipes.clear();
            names.clear();

            ResultSet rs=SimpleQueries.getRecipeFromNameCLAPAll(name, num, AP, conn);
            ResultSet pq=SimpleQueries.getImage(name, conn);
            if(!rs.first() || !pq.first()){
                MyException e = new MyException("Ricetta o immagine non trovata");
                throw e;
            }
            rs.first();
            num=0;
            do {
                // lettura delle colonne "by ricetta"
                ric=rs.getString("Ricetta");
                nome=rs.getString("Nome");
                allergies=rs.getString("Allergies");
                blob=pq.getBlob("IMG");

                image=blob.getBytes(1, (int) blob.length());
                recipes.add(new Recipe(ric, nome, image));
                StringTokenizer st = new StringTokenizer(allergies);
                while (st.hasMoreTokens()) {
                    recipes.get(num).addAll(st.nextToken());
                }
                num++;
            } while (rs.next() && pq.next());
            rs.close();
            pq.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        state++;
        return recipes;
    }

    public ArrayList<Recipe> searchRecipe(String time, String CL, String AP, String username) throws Exception{
        int num;
        ResultSet pq;

        try {
            num=instance.checkCL(CL,username);
            if(AP==null){
                AP=instance.getAP(username);
            }
            recipes.clear();
            names.clear();

            ResultSet rs=SimpleQueries.getRecipeFromTimeCLAPAll(time, num, AP, conn);
            if(!rs.first()){
                MyException e = new MyException("Ricetta non trovata");
                throw e;
            }
            rs.first();
            num=0;
            do {
                // lettura delle colonne "by ricetta"
                ric=rs.getString("Ricetta");
                nome=rs.getString("Nome");
                allergies=rs.getString("Allergies");

                if(num==0 || !names.get(num-1).equals(nome)) {
                    pq = SimpleQueries.getImageFromChef(ric, nome, conn);
                    if (!pq.first()) {
                        MyException e = new MyException("Immagine non trovata");
                        throw e;
                    }
                    blob = pq.getBlob("IMG");

                    image = blob.getBytes(1, (int) blob.length());
                    recipes.add(new Recipe(ric, nome, image));
                    StringTokenizer st = new StringTokenizer(allergies);
                    while (st.hasMoreTokens()) {
                        recipes.get(num).addAll(st.nextToken());
                    }
                    num++;

                    pq.close();
                    names.add(nome);
                }
            } while (rs.next());
            rs.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        state++;
        return recipes;
    }

    public ArrayList<Recipe> searchRecipeIngr(String ingr, String CL, String AP, String username) throws Exception{
        int num;
        ResultSet pq;

        try {
            num=instance.checkCL(CL,username);
            if(AP==null){
                AP=instance.getAP(username);
            }
            recipes.clear();
            names.clear();

            ResultSet rs=SimpleQueries.getRecipeFromIngrCLAPAll(ingr, num, AP, conn);
            if(!rs.first()){
                MyException e = new MyException("Ricetta non trovata");
                throw e;
            }
            rs.first();
            num=0;
            do {
                // lettura delle colonne "by ricetta"
                ric=rs.getString("Ricetta");
                nome=rs.getString("Nome");
                allergies=rs.getString("Allergies");

                if(num==0 || !names.get(num-1).equals(nome)) {
                    pq = SimpleQueries.getImageFromChef(ric, nome, conn);
                    if (!pq.first()) {
                        MyException e = new MyException("Immagine non trovata");
                        throw e;
                    }
                    blob = pq.getBlob("IMG");

                    image = blob.getBytes(1, (int) blob.length());
                    recipes.add(new Recipe(ric, nome, image));
                    StringTokenizer st = new StringTokenizer(allergies);
                    while (st.hasMoreTokens()) {
                        recipes.get(num).addAll(st.nextToken());
                    }
                    num++;

                    pq.close();
                    names.add(nome);
                }
            } while (rs.next());
            rs.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        state++;
        return recipes;
    }

    public ArrayList<Recipe> searchRecipeType(String type, String CL, String AP, String username) throws Exception{
        int num;
        ResultSet pq;

        try {
            num=instance.checkCL(CL,username);
            if(AP==null){
                AP=instance.getAP(username);
            }
            recipes.clear();
            names.clear();

            ResultSet rs=SimpleQueries.getRecipeFromTypeCLAPAll(type, num, AP, conn);
            if(!rs.first()){
                MyException e = new MyException("Ricetta non trovata");
                throw e;
            }
            rs.first();
            num=0;
            do {
                // lettura delle colonne "by ricetta"
                ric=rs.getString("Ricetta");
                nome=rs.getString("Nome");
                allergies=rs.getString("Allergies");

                if(num==0 || !names.get(num-1).equals(nome)) {
                    pq = SimpleQueries.getImageFromChef(ric, nome, conn);
                    if (!pq.first()) {
                        MyException e = new MyException("Immagine non trovata");
                        throw e;
                    }
                    blob = pq.getBlob("IMG");

                    image = blob.getBytes(1, (int) blob.length());
                    recipes.add(new Recipe(ric, nome, image));
                    StringTokenizer st = new StringTokenizer(allergies);
                    while (st.hasMoreTokens()) {
                        recipes.get(num).addAll(st.nextToken());
                    }
                    num++;

                    pq.close();
                    names.add(nome);
                }
            } while (rs.next());
            rs.close();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        state++;
        return recipes;
    }

    public int checkCL(String CL, String username){
        int i = 0;
        if(CL==null){
            i=instance.getCL(username);
        }else if(CL.toLowerCase().equals("beginner")){
            i=1;
        }else if(CL.toLowerCase().equals("intermediate")){
            i=2;
        }else if(CL.toLowerCase().equals("advanced")){
            i=3;
        }
        return i;
    }

    private int getCL(String username) {
        int i=0;

        try {
            ResultSet rs = SimpleQueries.selectUserFromName(username, conn);
            if (!rs.first()) {
                i = 0;
            } else {
                i = rs.getInt("CookingLevel");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return i;
    }

    public String getAP(String username){
        String ap = null;

        try {
            ResultSet rs=SimpleQueries.selectUserFromName(username, conn);
            rs.first();
            ap=rs.getString("AlimentarPreferences");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ap;
    }

    @Override
    protected boolean isThereAnythingToNotify(){
        boolean b= internalstate<state;
        internalstate=state;
        if(b) {
            this.doSomething();
        }
        return b;
    }

    protected void doSomething(){
        states=recipes;
    }

    public ArrayList<Recipe> getState(){
        return states;
    }
}
