package com.example.progettoispw;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class WeeklyPlanDAO {
    private Conn con;
    private Connection conn;
    private static WeeklyPlanDAO instance=null;

    private WeeklyPlanDAO(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static WeeklyPlanDAO getInstance(){
        if(WeeklyPlanDAO.instance==null)
            WeeklyPlanDAO.instance=new WeeklyPlanDAO();
        return instance;
    }

    public boolean getFromDB(String username) {
        boolean b;
        try {
            ResultSet rs = SimpleQueries.getSpecFromName(username, conn);
            if (!rs.first()) {
                MyException e = new MyException("Non si dispone di nessuna specializzazione");
                throw e;
            }
            String spec = rs.getString("Specializzazione");
            if (spec.equals("Premium")) {
                b = true;
            } else {
                b = false;
            }
            return b;
        }catch (MyException e) {
            e.printStackTrace();
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
