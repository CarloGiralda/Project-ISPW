package com.example.progettoispw;


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class StarterController {
    private int rem;
    private LogBean login;
    private String spec;
    private StarterControllerA sca;

    public StarterController(){
        sca=new StarterControllerA();
    }

    public void Start(Stage stage) throws IOException {
        try {
            login=sca.getSpec();
            if (login != null) {
                rem = login.getCheck();
                spec=login.getSpec();
                if (rem != 0 && (spec.equals("User") || spec.equals("Premium"))) {
                    Parent root = FXMLLoader.load(Objects.requireNonNull(StarterController.class.getResource("Home.fxml")));
                    stage.setScene(new Scene(root, 850, 594));
                    return;
                }else if(rem != 0 && spec.equals("Chef")){
                    Parent root = FXMLLoader.load(Objects.requireNonNull(StarterController.class.getResource("HomeChef.fxml")));
                    stage.setScene(new Scene(root, 850, 594));
                    return;
                }
            }
            Parent root = FXMLLoader.load(Objects.requireNonNull(StarterController.class.getResource("login.fxml")));
            stage.setScene(new Scene(root, 850, 594));
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
