package com.example.progettoispw;

import java.sql.*;
import java.util.ArrayList;

public class SavedDAO {
    private Conn con;
    private Connection conn;
    private static SavedDAO instance=null;

    private SavedDAO(){
        con=Conn.getInstance();
        conn=con.connect();
    }

    public static SavedDAO getInstance(){
        if (SavedDAO.instance == null)
            SavedDAO.instance = new SavedDAO();
        return instance;
    }

    public ArrayList<RecipeBean> saveddao(String username) throws Exception{
        ArrayList<RecipeBean> recipes=new ArrayList<>();
        int i=0;

        try {
            ResultSet rs = SimpleQueries.getSaved(username, conn);
            rs.first();
            do {
                // lettura delle colonne "by name"
                recipes.add(i, new RecipeBean(rs.getString("Ricetta")));
                i++;
            } while (rs.next());
            rs.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return recipes;
    }

    // metodo da copiare nella schermata di aggiunta di una ricetta ai preferiti e da eliminare da qui //
    public Recipe saveRecipeDB(Recipe recipe, String username){
        try {
            SimpleQueries.insertRecipeIntoSaved(recipe.getName(), username, conn);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return recipe;
    }
}
