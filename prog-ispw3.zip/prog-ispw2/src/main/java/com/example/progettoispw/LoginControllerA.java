package com.example.progettoispw;

import java.io.IOException;

public class LoginControllerA {
    private LoginDAO dao;
    private FileInterDAO filedao;

    public LoginControllerA(){
        filedao=FileInterDAO.getInstance();
    }

    public boolean checkUserAndPass(LogBean a) throws IOException {
        Login save=new Login();
        dao=LoginDAO.getInstance();
        save= dao.Login(a.getUser());
        if(a.getUser().equals(save.getUser()) && a.getPass().equals(save.getPass())){
            filedao.WriteLog(save);
            System.out.println("Login eseguito");
            return true;
        }else{
            System.out.println("Login fallito");
            return false;
        }
    }

    public void select() throws IOException, ClassNotFoundException {
        Login login=filedao.ReadLog();
        login.setCheck();
        filedao.WriteLog(login);
    }
}
