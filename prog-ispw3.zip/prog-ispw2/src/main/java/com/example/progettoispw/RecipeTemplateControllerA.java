package com.example.progettoispw;

import java.io.File;

public class RecipeTemplateControllerA {
    private RecipeBean rb;
    private RecipeTemplateDAO dao;
    private Recipe recipe;
    private FileInterDAO filedao;

    public RecipeTemplateControllerA(){
        filedao= FileInterDAO.getInstance();
        dao=RecipeTemplateDAO.getInstance();
    }

    public RecipeBean getRecipe(){
        recipe=dao.getRecipe();
        rb=Convert.ConvertEntityToBean(recipe);
        return rb;
    }
}
