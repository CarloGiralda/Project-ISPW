module com.example.interfacciaimpostazioni {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.interfacciaimpostazioni to javafx.fxml;
    exports com.example.interfacciaimpostazioni;
}