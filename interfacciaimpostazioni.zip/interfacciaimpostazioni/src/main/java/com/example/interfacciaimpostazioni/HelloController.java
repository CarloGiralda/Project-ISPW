package com.example.interfacciaimpostazioni;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

import static javafx.collections.FXCollections.observableArrayList;

public class HelloController {
@FXML
    private ComboBox languagecb=new ComboBox();
@FXML
    private ComboBox privacycb=new ComboBox();
@FXML
    private Button applybutton=new Button();
@FXML
    private ComboBox cookinglevelcb=new ComboBox();
@FXML
    private ComboBox notificationscb=new ComboBox();
@FXML
    private ComboBox accountcb=new ComboBox();
@FXML
    private ComboBox temacb=new ComboBox();
@FXML
    private ComboBox termsofusecb=new ComboBox();
@FXML
public void initialize()
{
    languagecb.setItems(observableArrayList("Italian","English"));
    privacycb.setItems(observableArrayList("private account yes","private account no"));
    cookinglevelcb.setItems(observableArrayList("beginner","souf-chef","expert-chef"));
    notificationscb.setItems(observableArrayList("yes","no"));
    accountcb.setItems(observableArrayList("cooker","chef"));
    temacb.setItems(observableArrayList("day","night"));
    termsofusecb.setItems(observableArrayList("Accept all","Do not accept"));

}


    public void gotohome(ActionEvent actionevent){
    }

    public void gotosaved(ActionEvent actionevent){

    }

    public void gotoadd(ActionEvent actionevent){

    }

    public void gotosettings(ActionEvent actionevent){

    }

    public void gotoplan(ActionEvent actionevent){

    }

    public void downlanguage(ActionEvent actionevent){



    }
    public void downprivacy(ActionEvent actionevent){

    }
    public void downcookinglevel(ActionEvent actionevent){

    }
    public void downtema(ActionEvent actionevent){

    }
    public void downnotifications(ActionEvent actionevent){

    }
    public void downtermsofuse(ActionEvent actionevent){

    }
    public void downaccount(ActionEvent actionevent){

    }

    public void apply(ActionEvent actionevent) {

       System.out.println("Cambiamento avvenuto");

    }



    }
