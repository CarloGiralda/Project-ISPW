package com.example.progettoispw;

import java.io.IOException;

public class AddRecipeControllerA {
    private AddRecipeDAO dao;
    private Login login;

    public AddRecipeControllerA() throws IOException, ClassNotFoundException {
        dao=new AddRecipeDAO();
        login=FileInter.ReadLog();
    }

    public void addRecipe(RecipeBean rb){
        dao.insertRecipe(rb, login.getUser());
    }
}
