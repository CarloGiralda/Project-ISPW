package com.example.progettoispw;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginControllerA {
    public boolean checkUserAndPass(LogBean a) throws IOException {
        LogBean temp1=new LogBean();
        LoginDAO dao=new LoginDAO();
        temp1= LoginDAO.Login(a.getUser());
        if(a.getUser().equals(temp1.getUser()) && a.getPass().equals(temp1.getPass())){
            Login login=new Login(a.getUser(), a.getPass());
            FileInter.WriteLog(login);
            System.out.println("Login eseguito");
            return true;
        }else{
            System.out.println("Login fallito");
            return false;
        }
    }

    public void select() throws IOException, ClassNotFoundException {
        Login login=FileInter.ReadLog();
        login.setCheck();
        FileInter.WriteLog(login);
    }
}
