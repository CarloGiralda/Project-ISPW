package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.w3c.dom.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class HomePageController {


    @FXML
    private Button planButton;
    @FXML
    private Button settingButton;
    @FXML
    private Button savedButton;
    @FXML
    private Button addRecipe;
    @FXML
    private Button recipesHistoryButton;
    @FXML
    private Button saveButton;
    @FXML
    private Button supermarketButton;
    @FXML
    private Button plusButton;
    @FXML
    private Button alimentarPreferences;


    private SavedControllerA sca;
    private ArrayList<String> recipes=new ArrayList<>();
    private ArrayList<Button> buttons=new ArrayList<>();

    public HomePageController(){
        sca=new SavedControllerA();
    }

    @FXML
    public int showRecipesHistory(){
        return 1;
    }
    @FXML
    public int showSavedRecipes(){
        return 1;
    }
    @FXML
    public int showSupermarkets(){
        return 1;
    }
    @FXML
    public int plusaction(){
        return 1;
    }
    @FXML
    public void gotoweeklyplan() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("weeklyplan.fxml")));
        Stage window=(Stage) planButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void gotoSettings() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Settings.fxml")));
        Stage window=(Stage) settingButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void gotoSaved() throws Exception {
        Pane root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("saved.fxml")));
        Stage window=(Stage) savedButton.getScene().getWindow();
        recipes=sca.saved("ciao");
        if(recipes.size()>0){
            for(int i = 0; i< recipes.size(); i++) {
                buttons.add(i, new Button(recipes.get(i)));
                buttons.get(i).setLayoutX(28);
                buttons.get(i).setLayoutY(145 + (i * 30));
                root.getChildren().add(buttons.get(i));
            }
        }
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    private AnchorPane paneRecipe;
    @FXML
    private AnchorPane paneHome;
    @FXML
    private Button addRecipeButton;
    @FXML
    private Button searchRecipeButton;

    @FXML
    private Label l1;
    @FXML
    private Label l2;
    @FXML
    private Label l3;
    @FXML
    private Label l4;
    @FXML
    private Label l5;

    //private final Label[] allLabel= {l1,l2,l3,l4,l5};


    @FXML
    public void gotoRecipeMenu() throws IOException {
        /*
        Parent root = FXMLLoader.load(getClass().getResource("AggiungiRicetta.fxml"));
        Stage window = (Stage) addRecipe.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
        */
        final Label[] allLabel= {l1,l2,l3,l4,l5};

        for(int i=0;i<5;i++){
            allLabel[i].setOpacity(0);
            allLabel[i].setDisable(true);

        }

        paneHome.toBack();
        paneHome.setOpacity(0);
        paneHome.setDisable(true);

        paneRecipe.toFront();
        paneRecipe.setOpacity(1);
        paneRecipe.setDisable(false);

    }

    @FXML
    public void gotoAddRecipe() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Add-recipe.fxml")));
        Stage window=(Stage) addRecipeButton.getScene().getWindow();
        window.setScene(GeneralScene.getAdd(root));
    }

}
