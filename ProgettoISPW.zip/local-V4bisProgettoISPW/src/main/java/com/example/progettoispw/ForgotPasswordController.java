package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;


public class ForgotPasswordController {
    @FXML
    private Button back;
    @FXML
    private TextField mail;
    @FXML
    private Button send;
    @FXML
    private Button submit;
    @FXML
    private TextField OTP;
    @FXML
    private Label lab;

    private String email;
    private String random;
    private int num;
    private String password;

    @FXML
    public void goBack() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Stage window=(Stage) back.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void sendEmail() throws IOException {
        if(send.getOpacity()==1) {
            // BISOGNA CONTROLLARE LA MAIL SE C'E' NEL DATABASE
            email = mail.getText();
            num = (int) Math.random();
            random = Integer.toString(num);
        //    SendMail.send(random, email);
            OTP.setOpacity(1);
            OTP.setText("");
            send.setOpacity(0);
            submit.setOpacity(1);
        }
    }

    @FXML
    public void Submit(){
        if(submit.getOpacity()==1){
            if(OTP.getText().equals(random)){
                password=ForgotDAO.passRec(email);
                lab.setText(password);
            }else{
                lab.setText("Incorrect OTP");
            }
        }
    }
}
