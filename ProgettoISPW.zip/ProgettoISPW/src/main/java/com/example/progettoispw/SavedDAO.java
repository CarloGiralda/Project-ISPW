package com.example.progettoispw;

import java.sql.*;

public class SavedDAO {
    private static String USER = "Progetto";
    private static String PASS = "";
    private static String DB_URL = "jdbc:mysql://192.168.1.6:3306/progettoispw-db";
    private static String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";

    public RecipeBean[] saveddao(String username) throws Exception{
        Statement stmt = null;
        Connection conn = null;
        RecipeBean[] recipes=new RecipeBean[512];
        int i=0;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = SimpleQueries.getSaved(username, conn);
            if (!rs.first()) { // rs empty
                Exception e = new Exception("No recipes found for the user " + username);
                throw e;
            }
            rs.first();
            do {
                // lettura delle colonne "by name"
                recipes[i].setName(rs.getString("Ricetta"));
                i++;
            } while (rs.next());
            rs.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return recipes;
    }
}
