package com.example.progettoispw;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    @FXML
    private TextField username;
    @FXML
    private TextField password;

    @FXML
    private Button registerlink;

    @FXML
    private Button login = new Button();
    @FXML
    private Button forgotPasswordButton=new Button();
    @FXML
    private Button googleLoginButton= new Button();
    @FXML
    private CheckBox rememberMeCheckBox= new CheckBox();
    @FXML
    private Label Wrong=new Label();

    private String str1,str2;
    private LoginControllerA app;

    public LoginController(){
        app=new LoginControllerA();
    }

    @FXML
    public int gotoForgotPassword(){
        return 1;
    }
    @FXML
    public void rememberMe() throws IOException, ClassNotFoundException {
        if(rememberMeCheckBox.isSelected()){
            app.select();
        }
    }

    @FXML
    public int gotoGoogleLogin() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
        Stage window=(Stage) googleLoginButton.getScene().getWindow();
        window.setScene(new Scene(root, 240, 400));
        return 1;
    }
    @FXML
    public void checkUsernameAndPassword() throws IOException {
        str1 = username.getText();
        str2 = password.getText();
        System.out.println(str1+' '+str2);

        LogBean temp=new LogBean(str1,str2);
        if(app.checkUserAndPass(temp)==true) {
            Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
            Stage window = (Stage) login.getScene().getWindow();
            window.setScene(new Scene(root, 240, 400));
        }else{
            Wrong.setOpacity(1);
            username.setText("");
            password.setText("");
        }
    }

    @FXML
    public void gotoRegisterNow() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("RegisterPage.fxml"));
        Stage window=(Stage) registerlink.getScene().getWindow();
        window.setScene(new Scene(root, 240, 400));
    }
}