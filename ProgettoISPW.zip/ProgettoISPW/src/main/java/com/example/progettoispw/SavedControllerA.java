package com.example.progettoispw;

public class SavedControllerA {
    String[] recipes=new String[512];
    RecipeBean[] rcp=new RecipeBean[512];

    public String[] saved(String username) throws Exception {
        SavedDAO saved=new SavedDAO();
        rcp=saved.saveddao(username);
        for(int i=0; i<512; i++){
            recipes[i]=rcp[i].getName();
        }
        return recipes;
    }
}
