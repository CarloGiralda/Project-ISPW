package com.example.progettoispw;

import java.sql.*;

public class SimpleQueries {
    public static ResultSet selectUserFromName(String username, Connection conn) throws SQLException {
        String sql = "SELECT * FROM Utenti where Username = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static int insertUser(String username, String password, String cl, String email, String spec, Connection conn) throws SQLException {
        String sql = "INSERT INTO Utenti(Username, Password, Specializzazione, CookingLevel, Email) values (?,?,?,?,?)";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        prep.setString(2, password);
        prep.setString(3, spec);
        prep.setString(4, cl);
        prep.setString(5, email);
        System.out.println(sql);
        return prep.executeUpdate();
    }

    public static ResultSet getSaved(String username, Connection conn) throws SQLException {
        String sql = "SELECT * FROM Saved where Username = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        System.out.println(sql);
        return prep.executeQuery();
    }
}
