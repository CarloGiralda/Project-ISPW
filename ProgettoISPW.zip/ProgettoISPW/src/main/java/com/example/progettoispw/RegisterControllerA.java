package com.example.progettoispw;

public class RegisterControllerA {
    public void register(LogBean log){
        RegisterDAO dao=new RegisterDAO();
        dao.registerdao(log);
    }
}
