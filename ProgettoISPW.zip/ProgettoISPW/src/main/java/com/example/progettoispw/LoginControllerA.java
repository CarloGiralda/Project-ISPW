package com.example.progettoispw;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class LoginControllerA {
    public boolean checkUserAndPass(LogBean a){
        LogBean temp1=new LogBean();
        LoginDAO dao=new LoginDAO();
        temp1= LoginDAO.Login(a.getUser());
        if(a.getUser().equals(temp1.getUser()) && a.getPass().equals(temp1.getPass())){
            System.out.println("Login eseguito");
            return true;
        }else{
            System.out.println("Login fallito");
            return false;
        }
    }
}
