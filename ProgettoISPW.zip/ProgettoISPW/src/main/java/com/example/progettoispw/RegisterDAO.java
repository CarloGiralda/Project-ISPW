package com.example.progettoispw;

import java.sql.*;

public class RegisterDAO {
    private static String USER = "Progetto";
    private static String PASS = "";
    private static String DB_URL = "jdbc:mysql://192.168.1.6:3306/progettoispw-db";
    private static String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";

    public void registerdao(LogBean log) throws Exception{
        Statement stmt = null;
        Connection conn = null;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            ResultSet rs = SimpleQueries.selectUserFromName(log.getUser(), conn);
            if (!rs.first()) { // rs empty
                SimpleQueries.insertUser(log.getUser(), log.getPass(), log.getCL(), log.getEmail(), log.getSpec(), conn);
            }else{
                Exception e = new Exception("User already registered: " + log.getUser());
                throw e;
            }
            rs.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
