package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class RecipeController {
    @FXML
    private TextField CookingLevel;
    @FXML
    private TextField CookingTime;
    @FXML
    private TextField Type;
    @FXML
    private TextField AlimentarPreferences;
    @FXML
    private TextField Ingredients;
    @FXML
    private TextField Preparation;
    @FXML
    private TextField Details;
}
