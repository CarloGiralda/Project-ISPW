package com.example.progettoispw;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class RegisterPageController {
    @FXML
    private Button registerButton;
    @FXML
    private TextField specField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField passwordField;
    @FXML
    private TextField usernameField;
    @FXML
    private TextField cookingLevelField;

    private LogBean a;

    public RegisterPageController() { a=new LogBean(); }

    @FXML
    public void gotoHome() throws IOException {
        a.setSpec(specField.getText());
        a.setEmail(emailField.getText());
        a.setUser(usernameField.getText());
        a.setPass(passwordField.getText());
        a.setCL(cookingLevelField.getText());
        RegisterControllerA reg=new RegisterControllerA();
        reg.register(a);
        Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
        Stage window=(Stage) registerButton.getScene().getWindow();
        window.setScene(new Scene(root, 240, 400));
    }
}
