package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class AddRecipeController {
    @FXML
    private TextArea InsertTitle;
    @FXML
    private TextArea AddDescription;
    @FXML
    private TextArea SetCookingParameter;
    @FXML
    private TextArea InsertImages;
}
