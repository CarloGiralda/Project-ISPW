package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;

public class AddRecipeController {
    @FXML
    private TextArea InsertTitle;
    @FXML
    private TextArea AddDescription;
    @FXML
    private TextArea SetCookingParameter;
    @FXML
    private TextArea InsertImages;
    @FXML
    private Button X;
    @FXML
    private Button V;

    @FXML
    public void goBack() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AggiungiRicetta.fxml"));
        Stage window = (Stage) X.getScene().getWindow();
        window.setScene(new Scene(root, 240, 400));
    }
}
