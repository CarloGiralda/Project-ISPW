package com.example.progettoispw;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class HomePageController {


    @FXML
    private Button planButton;
    @FXML
    private Button settingButton;
    @FXML
    private Button savedButton;
    @FXML
    private Button addRecipe;
    @FXML
    private Button recipesHistoryButton;
    @FXML
    private Button saveButton;
    @FXML
    private Button supermarketButton;
    @FXML
    private Button plusButton;
    @FXML
    private Button alimentarPreferences;


    private SavedControllerA sca;
    private ArrayList<String> recipes=new ArrayList<>();
    private ArrayList<Button> buttons=new ArrayList<>();

    public HomePageController(){
        sca=new SavedControllerA();
    }

    @FXML
    public int showRecipesHistory(){
        return 1;
    }
    @FXML
    public int showSavedRecipes(){
        return 1;
    }
    @FXML
    public int showSupermarkets(){
        return 1;
    }
    @FXML
    public int plusaction(){
        return 1;
    }
    @FXML
    public void gotoweeklyplan() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("weeklyplan.fxml"));
        Stage window=(Stage) planButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void gotoImpostazioni() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Impostazioni.fxml"));
        Stage window=(Stage) settingButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void gotoSaved() throws Exception {
        Pane root = FXMLLoader.load(getClass().getResource("saved.fxml"));
        Stage window=(Stage) savedButton.getScene().getWindow();
        recipes=sca.saved("ciao");
        if(recipes.size()>0){
            for(int i = 0; i< recipes.size(); i++) {
                buttons.add(i, new Button(recipes.get(i)));
                buttons.get(i).setLayoutX(28);
                buttons.get(i).setLayoutY(145 + (i * 30));
                root.getChildren().add(buttons.get(i));
            }
        }
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void gotoAddRecipe() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AggiungiRicetta.fxml"));
        Stage window = (Stage) addRecipe.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }
}
