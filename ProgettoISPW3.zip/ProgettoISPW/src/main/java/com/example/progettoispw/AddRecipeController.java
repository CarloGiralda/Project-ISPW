package com.example.progettoispw;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public class AddRecipeController {
    @FXML private TextArea insertTitle;
    @FXML private TextArea addDescription;
    @FXML private TextArea preparationTime;
    @FXML private TextArea cookingTime;

    @FXML Label dtype;
    @FXML MenuItem m1;
    @FXML MenuItem m2;
    @FXML MenuItem m3;
    @FXML MenuItem m4;
    @FXML MenuItem m5;
    @FXML MenuItem m6;

    @FXML private Button addIngredient;

    @FXML private TextField ingredientName;
    @FXML private TextField ingredientAmount;

    @FXML Label selectedButton;


    @FXML private Button uploadImage;

    @FXML private Button X;
    @FXML private Button V;


    @FXML
    public void handleDishType(ActionEvent actionEvent){
        dtype.setText(((MenuItem)actionEvent.getSource()).getText());
        System.out.println(dtype.getText() + " selected");

    }

    @FXML
    public void handleDifficult(ActionEvent actionEvent){
        selectedButton.setText(((RadioButton)actionEvent.getSource()).getText());
        System.out.println(selectedButton.getText() + " selected");

    }

    @FXML
    public void goBack() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AggiungiRicetta.fxml"));
        Stage window = (Stage) X.getScene().getWindow();
        window.setScene(new Scene(root, 240, 400));
    }

    @FXML
    public void handleUploadImage(){
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images file","*.jpg","*.png"));

        try{
            File file = fc.showOpenDialog(null);
            fc.setInitialDirectory(file.getParentFile());
        }
        catch (Exception ex){
            //TODO
        }
    }


    @FXML
    public void sendRecipeDetailsOnCommit() throws IOException{
        String title = insertTitle.getText();
        String description = addDescription.getText();

        String pT = preparationTime.getText();
        String cT = cookingTime.getText();
        int preparationTime = convertIntParameter(pT);
        int cookingTime = convertIntParameter(cT);

        String iName = ingredientName.getText();
        int iAmount = convertIntParameter(ingredientAmount.getText());

        String type = selectedButton.getText();


        System.out.println(title+'\n'+type+'\n'+description+'\n'+preparationTime+'\n'+cookingTime+'\n'+iName+'\n'+iAmount);

        //RecipeBean rb = new RecipeBean();
        //AddRecipeApplicativeController c = new AddRecipeApplicativeController();
        //c.compileRecipe(rb);

    }

    @FXML
    public void handleAddIngredient(){
        System.out.println("Clicked");
    }


    public int convertIntParameter(String str){
        int value = 0;
        try{
            value = Integer.parseInt(str);
        }
        catch (NumberFormatException ex){
            ex.printStackTrace();
        }
        return value;
    }


}