package com.example.progettoispw;

import com.example.progettoispw.RecipeModel.Ingredient;

import java.sql.*;
import java.util.ArrayList;

public class SimpleQueries {
    public static ResultSet selectUserFromName(String username, Connection conn) throws SQLException {
        String sql = "SELECT * FROM Utenti where Username = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static int insertUser(String username, String password, String cl, String email, String spec, Connection conn) throws SQLException {
        String sql = "INSERT INTO Utenti(Username, Password, Specializzazione, CookingLevel, Email) values (?,?,?,?,?)";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        prep.setString(2, password);
        prep.setString(3, spec);
        prep.setString(4, cl);
        prep.setString(5, email);
        System.out.println(sql);
        return prep.executeUpdate();
    }

    public static ResultSet getSaved(String username, Connection conn) throws SQLException {
        String sql = "SELECT * FROM ricettesalvate where Nome = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static ResultSet getRecipeFromName(String name, Connection conn) throws SQLException{
        String sql= "SELECT * FROM ricetteinserite where Nome = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, name);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static int insertRecipeIntoSaved(String name, String username, Connection conn) throws SQLException{
        String sql= "INSERT INTO ricettesalvate(Nome, Ricetta) values(?,?)";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        prep.setString(2, name);
        System.out.println(sql);
        return prep.executeUpdate();
    }

    public static int insertCookingLevel(int cook, String username, Connection conn) throws SQLException {
        String sql= "UPDATE utenti SET CookingLevel=? WHERE Username=?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setInt(1, cook);
        prep.setString(2, username);
        System.out.println(sql);
        return prep.executeUpdate();
    }

    public static ResultSet getPassFromEmail(String email, Connection conn) throws SQLException {
        String sql= "SELECT Password FROM utenti where Email = ?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, email);
        System.out.println(sql);
        return prep.executeQuery();
    }

    public static int setUserFromName(String nameSet, String oldName, Connection conn) throws SQLException {
        String sql= "UPDATE utenti SET Username=? WHERE Username=?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, nameSet);
        prep.setString(2, oldName);
        System.out.println(sql);
        return prep.executeUpdate();
    }

    public static int setPassFromName(String password, String username, Connection conn) throws SQLException {
        String sql= "UPDATE utenti SET Password=? WHERE Username=?";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, password);
        prep.setString(2, username);
        System.out.println(sql);
        return prep.executeUpdate();
    }

    public static int insertRecipeFromIngredient(String username, String title, String ingredient, int level, String time, String AP, String type, String description, String amount, Connection conn) throws SQLException {
        String sql= "INSERT INTO ricetteinserite(Nome, Ricetta, Ingrediente, Livello, Tempo, Intolleranza, Type, Description, Ammontare) values(?,?,?,?,?,?,?,?,?)";
        PreparedStatement prep=conn.prepareStatement(sql);
        prep.setString(1, username);
        prep.setString(2, title);
        prep.setString(3, ingredient);
        prep.setInt(4, level);
        prep.setString(5, time);
        prep.setString(6, AP);
        prep.setString(7, type);
        prep.setString(8, description);
        prep.setString(9, amount);
        System.out.println(sql);
        return prep.executeUpdate();
    }
}
