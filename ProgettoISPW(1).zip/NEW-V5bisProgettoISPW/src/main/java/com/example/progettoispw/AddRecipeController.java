package com.example.progettoispw;

import com.example.progettoispw.RecipeModel.Ingredient;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class AddRecipeController {
    @FXML private TextArea insertTitle;
    @FXML private TextArea addDescription;
    @FXML private TextArea alimentarPreferences;
    @FXML private TextArea cookingTime;

    @FXML Label dtype;

    @FXML private MenuButton dtypeMenu;
    @FXML private MenuItem m1;
    @FXML private MenuItem m2;
    @FXML private MenuItem m3;
    @FXML private MenuItem m4;
    @FXML private MenuItem m5;
    @FXML private MenuItem m6;

    @FXML private Button addIngredient;

    @FXML private TextField ingredientName;
    @FXML private TextField ingredientAmount;

    @FXML Label selectedButton;

    @FXML private Button uploadImage;

    @FXML private Button goBackButton;
    @FXML private Button confirmRecipeButton;

    @FXML private ScrollPane upper;

    private AddRecipeControllerA arca;
    private String cookingLevel;
    private ArrayList<Text> ingredient;
    private ArrayList<TextField> name;
    private ArrayList<TextField> amount;
    private int i;
    private ScrollPane root;
    private Stage window;
    private Button Add;
    private ArrayList<Ingredient> ingredients;

    public AddRecipeController() throws IOException, ClassNotFoundException {
        arca=new AddRecipeControllerA();
        ingredient=new ArrayList<>();
        name=new ArrayList<>();
        amount=new ArrayList<>();
        i=IndexTrace.get();
        Add=new Button();
        ingredients=new ArrayList<>();
    }

    @FXML
    public void handleDishType(ActionEvent actionEvent){
        dtype.setText(((MenuItem)actionEvent.getSource()).getText());
        dtypeMenu.setText(dtype.getText());
        System.out.println(dtype.getText() + " selected");

    }

    @FXML
    public void handleDifficult(ActionEvent actionEvent){
        selectedButton.setText(((RadioButton)actionEvent.getSource()).getText());
        System.out.println(selectedButton.getText() + " selected");
        if(selectedButton.getText().equals("B")){
            cookingLevel="Beginner";
        }else if(selectedButton.getText().equals("I")){
            cookingLevel="Intermediate";
        }else if(selectedButton.getText().equals("A")){
            cookingLevel="Advanced";
        }
    }

    @FXML
    public void goBack() throws IOException {
        //TODO Forse è possibile usare pattern GOF state per tornare nella home, nello stato recipe.
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Home.fxml")));
        Stage window = (Stage) goBackButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
        GeneralScene.deleteAddTemp();
    }

    @FXML
    public void handleUploadImage(){
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Images file","*.jpg","*.png"));

        try{
            File file = fc.showOpenDialog(null);
            fc.setInitialDirectory(file.getParentFile());
        }
        catch (Exception ex){
            //TODO
        }
    }


    @FXML
    public void commitRecipe() throws IOException{
        String title = insertTitle.getText();
        String description = addDescription.getText();

        String aP = alimentarPreferences.getText();
        String cT = cookingTime.getText();
        int cookingTime = convertIntParameter(cT);
        Ingredient ing=new Ingredient(ingredientName.getText(), ingredientAmount.getText());
        ingredients.add(ing);

        for(int i=1; i<IndexTrace.get()+1; i++){
            ing.setName(name.get(i-1).getText());
            ing.setAmount(amount.get(i-1).getText());
            ingredients.add(ing);
        }

        String type = selectedButton.getText();

        if(!title.isEmpty() && !description.isEmpty() && !aP.isEmpty() && !cT.isEmpty() && !ingredientName.getText().isEmpty() && !ingredientAmount.getText().isEmpty()){
            //TODO send recipe
            RecipeBean rb = new RecipeBean(title);
            rb.setType(type);
            rb.setCookingLevel(cookingLevel);
            rb.setDescription(description);
            rb.setAP(aP);
            rb.setCT(cT);
            for(int i=0; i<IndexTrace.get()+1; i++){
                rb.addIngredient(ingredients.get(i));
            }

            arca.addRecipe(rb);
        }

        System.out.println(title+'\n'+type+'\n'+description+'\n'+aP+'\n'+cookingTime+'\n'+ingredientName+'\n'+ingredientAmount.getText());
    }

    @FXML
    public void handleAddIngredient() throws IOException {
        System.out.println("Clicked");
        i=IndexTrace.get();

        Text ingr=new Text();
        ingr.setText("Ingredient:");
        ingr.setFont(Font.font("Century Gothic", 14));
        ingredient.add(i, ingr);

        TextField n=new TextField();
        n.setPromptText("name");
        n.setPrefSize(124, 27.33333332);
        n.setFont(Font.font("Century Gothic", 14));
        name.add(i, n);

        TextField am=new TextField();
        am.setPromptText("amount");
        am.setPrefSize(124, 27.33333332);
        am.setFont(Font.font("Century Gothic", 14));
        amount.add(i, am);

        ingredient.get(i).setLayoutX(255);
        ingredient.get(i).setLayoutY(519+i*35);

        name.get(i).setLayoutX(338);
        name.get(i).setLayoutY(500+i*35);

        amount.get(i).setLayoutX(472);
        amount.get(i).setLayoutY(500+i*35);

        Add.setText("Add");
        Add.setFont(Font.font("Centhury Gothic", 24));
        Add.setLayoutX(372);
        Add.setLayoutY(540+i*35);
        Add.setPrefSize(107.333333333, 47.333333333);
        Add.getStylesheets().add("src/main/resources/Style/ButtonLoginStyle.css");
        Add.setOnAction(confirmRecipeButton.getOnAction());

        Pane original= (Pane) insertTitle.getParent().getParent();
        original.getChildren().add(ingredient.get(i));
        original.getChildren().add(name.get(i));
        original.getChildren().add(amount.get(i));
        original.setMinHeight(original.getPrefHeight()+i*35);
        if(i==0) {
            confirmRecipeButton.setOpacity(0);
            original.getChildren().add(Add);
        }else{
            original.getChildren().remove(Add);
            original.getChildren().add(Add);
        }
        upper.setContent(original);
        IndexTrace.add();
        window = (Stage) insertTitle.getScene().getWindow();
        window.setScene(GeneralScene.getAddTemp(upper));
        //TODO
    }


    //TODO nel controller applicativo
    public int convertIntParameter(String str){
        int value = 0;
        try{
            value = Integer.parseInt(str);
        }
        catch (NumberFormatException ex){
            ex.printStackTrace();
        }
        return value;
    }


}