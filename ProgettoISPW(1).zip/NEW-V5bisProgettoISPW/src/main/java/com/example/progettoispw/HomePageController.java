package com.example.progettoispw;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;

public class HomePageController {


    @FXML
    private AnchorPane paneHome;
    @FXML
    private AnchorPane paneRecipe;
    @FXML
    private AnchorPane paneSearchRecipe;

    @FXML
    private Button homeButton;
    @FXML
    private Button planButton;
    @FXML
    private Button settingButton;
    @FXML
    private Button savedButton;
    @FXML
    private Button recipeButton;

    @FXML
    private Button recipesHistoryButton;
    @FXML
    private Button supermarketButton;
    @FXML
    private Button shoppingListButton;
    @FXML
    private Button alimentarPreferencesButton;

    @FXML
    private Button addRecipeButton;
    @FXML
    private Button searchRecipeButton;
    @FXML
    private Button myListButton;

    @FXML
    private TextField searchField;

    @FXML
    private Label l1;
    @FXML
    private Label l2;
    @FXML
    private Label l3;
    @FXML
    private Label l4;
    @FXML
    private Label l5;

    private final SavedControllerA sca;
    private final ArrayList<Button> buttons=new ArrayList<>();

    public HomePageController(){
        sca=new SavedControllerA();
    }

    @FXML
    public void showRecipesHistory() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("History.fxml")));
        Stage window=(Stage) recipesHistoryButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }


    @FXML
    public void showAlimentarPreferences() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("AlimentarPreferences.fxml")));
        Stage window=(Stage) alimentarPreferencesButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    //TODO
    @FXML
    public int showSavedRecipes(){
        return 1;
    }

    @FXML
    public void showSupermarkets() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Maps.fxml")));
        Stage window=(Stage) supermarketButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }


    @FXML
    public void showShoppingList() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ShoppingList.fxml")));
        Stage window=(Stage) shoppingListButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML //TODO da rivedere: bug quando si cambia schermata
    public void gotoHome(){
        if (checkPaneState(paneHome)){

            final Label[] allLabels= {l1,l2,l3,l4,l5};

            homeButton.getStyleClass().removeAll("button, focus");
            homeButton.getStyleClass().add("buttonAfterClick");

            disablePane(paneRecipe,true);
            disablePane(paneSearchRecipe,true);
            disablePane(paneHome,false);
            setAllLabels(allLabels);

        }
        else{
            System.out.println("Remain");
        }
    }

    @FXML
    public void gotoweeklyplan() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("weeklyplan.fxml")));
        Stage window=(Stage) planButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void gotoSettings() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Settings.fxml")));
        Stage window=(Stage) settingButton.getScene().getWindow();
        window.setScene(new Scene(root, 850, 594));
    }

    @FXML
    public void gotoSaved() throws Exception {
        Pane root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("saved.fxml")));
        Stage window=(Stage) savedButton.getScene().getWindow();
        ArrayList<String> recipes = sca.saved("ciao");
        if(recipes.size()>0){
            for(int i = 0; i< recipes.size(); i++) {
                buttons.add(i, new Button(recipes.get(i)));
                buttons.get(i).setLayoutX(28);
                buttons.get(i).setLayoutY(145 + (i * 30));
                root.getChildren().add(buttons.get(i));
            }
        }
        window.setScene(new Scene(root, 850, 594));
    }


    @FXML
    public void gotoRecipeMenu(ActionEvent event) throws IOException {

        if(checkPaneState(paneRecipe)) {

            //Button selected = (Button)event.getSource();
            recipeButton.getStyleClass().removeAll("button, focus");
            recipeButton.getStyleClass().add("buttonAfterClick");

            final Label[] allLabels = {l1, l2, l3, l4, l5};

            disablePane(paneHome, true);
            disablePane(paneRecipe, false);
            disablePane(paneSearchRecipe, true);
            setAllLabels(allLabels);
        }
        else{
            System.out.println("Remain");
        }

    }

    @FXML
    public void gotoAddRecipe() throws IOException {
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("Add-recipe.fxml")));
        Stage window=(Stage) addRecipeButton.getScene().getWindow();
        window.setScene(GeneralScene.getAdd(root));
    }

    @FXML
    public void handleSearchRecipeMenu(ActionEvent event) {
        Object source = event.getSource();

        if (searchRecipeButton.equals(source)) {
            disablePane(paneRecipe,true);
            disablePane(paneSearchRecipe,false);
        }

        else if (myListButton.equals(source)) {
            System.out.println("Clicked");
            //TODO
        }
    }



    //Metodi per attivare o disattivare le schermate e controllare il loro stato
    private void disablePane(AnchorPane pane,boolean able) {
        if (able) {
            pane.toBack();
            pane.setOpacity(0);
            pane.setDisable(true);
        }
        else{
            pane.toFront();
            pane.setOpacity(1);
            pane.setDisable(false);
        }
    }

    private boolean checkPaneState(AnchorPane pane){
        return !(pane.getOpacity() == 1);
    }


    private void setAllLabels(Label[] allLabels){
        if (allLabels[0].getOpacity() == 1) {
            for (int i = 0; i < 5; i++) {
                allLabels[i].setOpacity(0);
                allLabels[i].setDisable(true);
            }
        }
        else{
            for (int i = 0; i < 5; i++) {
                allLabels[i].setOpacity(1);
                allLabels[i].setDisable(false);
            }
        }

    }
}
