package com.example.progettoispw;

import java.sql.*;
import java.util.ArrayList;

public class AlimentarDAO {
    private static String USER = "Progetto";
    private static String PASS = "";
    private static String DB_URL = "jdbc:mysql://localhost:3306/progettoispw-db";
    private static String DRIVER_CLASS_NAME = "com.mysql.jdbc.Driver";

    public static void insertAP(String username, String pref, ArrayList<String> all){
        Statement stmt = null;
        Connection conn = null;

        try {
            // STEP 2: loading dinamico del driver mysql
            Class.forName(DRIVER_CLASS_NAME);

            // STEP 3: apertura connessione
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // STEP 4: creazione ed esecuzione della query
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                    ResultSet.CONCUR_READ_ONLY);

            SimpleQueries.insertAlimentarPreferences(username, pref, conn);
            if(!all.get(0).equals("No allergies")) {
                for (int i = 0; i < all.size(); i++) {
                    SimpleQueries.insertAllergies(username, all.get(i), conn);
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
